# slots-ai-response
Uses LLM to generate an AI response to slot machine game
